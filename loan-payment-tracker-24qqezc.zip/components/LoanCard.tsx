import { View, Text, StyleSheet, Pressable } from 'react-native';
import { router } from 'expo-router';
import { Calendar, TrendingUp } from 'lucide-react-native';
import { colors } from '@/constants/colors';
import { Loan } from '@/types/loan';

interface LoanCardProps {
  loan: Loan;
}

export function LoanCard({ loan }: LoanCardProps) {
  const handlePress = () => {
    router.push(`/loan/${loan.id}`);
  };

  return (
    <Pressable 
      style={styles.container}
      onPress={handlePress}
    >
      <View style={styles.header}>
        <Text style={styles.title}>{loan.title}</Text>
        <View style={[
          styles.badge,
          { backgroundColor: loan.remainingAmount > 0 ? colors.primary : colors.success }
        ]}>
          <Text style={styles.badgeText}>
            {loan.remainingAmount > 0 ? 'Active' : 'Paid'}
          </Text>
        </View>
      </View>

      <View style={styles.amounts}>
        <Text style={styles.amount}>
          {loan.currency} {loan.remainingAmount.toLocaleString()}
        </Text>
        <Text style={styles.subtitle}>remaining</Text>
      </View>

      <View style={styles.footer}>
        <View style={styles.footerItem}>
          <Calendar size={16} color={colors.textSecondary} />
          <Text style={styles.footerText}>
            Due {new Date(loan.nextPaymentDue).toLocaleDateString()}
          </Text>
        </View>
        <View style={styles.footerItem}>
          <TrendingUp size={16} color={colors.textSecondary} />
          <Text style={styles.footerText}>
            {loan.interestRate}% APR
          </Text>
        </View>
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: colors.card,
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: colors.border,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  title: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.text,
  },
  badge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
  },
  badgeText: {
    color: colors.text,
    fontSize: 12,
    fontWeight: '500',
  },
  amounts: {
    marginBottom: 16,
  },
  amount: {
    fontSize: 24,
    fontWeight: '700',
    color: colors.text,
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 14,
    color: colors.textSecondary,
  },
  footer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  footerItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  footerText: {
    fontSize: 14,
    color: colors.textSecondary,
  },
});