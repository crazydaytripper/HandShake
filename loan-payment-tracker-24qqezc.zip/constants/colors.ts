export const colors = {
  background: '#0A0A0B',
  card: '#141417',
  text: '#FFFFFF',
  textSecondary: '#71717A',
  primary: '#8B5CF6',
  primaryLight: '#A78BFA',
  success: '#22C55E',
  error: '#EF4444',
  border: '#27272A',
  inputBackground: '#18181B'
};