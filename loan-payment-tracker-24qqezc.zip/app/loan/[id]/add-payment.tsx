import { useState } from 'react';
import { View, Text, StyleSheet, TextInput, ScrollView, Pressable, Image } from 'react-native';
import { Stack, useLocalSearchParams, router } from 'expo-router';
import * as ImagePicker from 'expo-image-picker';
import * as FileSystem from 'expo-file-system';
import { Image as Upload } from 'lucide-react-native';
import { useLoanStore } from '@/stores/loan-store';
import { colors } from '@/constants/colors';

const formatNumber = (num: string) => {
  const number = num.replace(/,/g, '');
  if (/^\d*$/.test(number)) {
    return number.replace(/\B(?=(\d{3})+(?!\d))/g, ',');
  }
  return num;
};

const unformatNumber = (str: string) => str.replace(/,/g, '');

export default function AddPaymentScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const loan = useLoanStore(state => state.loans.find(l => l.id === id));
  const addPayment = useLoanStore(state => state.addPayment);
  
  const [amount, setAmount] = useState('');
  const [note, setNote] = useState('');
  const [month, setMonth] = useState('');
  const [day, setDay] = useState('');
  const [year, setYear] = useState('');
  const [receiptUri, setReceiptUri] = useState<string | null>(null);

  const handleAmountChange = (text: string) => {
    const formatted = formatNumber(text);
    setAmount(formatted);
  };

  const pickReceipt = async () => {
    try {
      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: true,
        aspect: [3, 4],
        quality: 0.8,
      });

      if (!result.canceled) {
        const newUri = result.assets[0].uri;
        // Create a unique filename for the receipt
        const filename = `receipt_${Date.now()}.jpg`;
        const directory = `${FileSystem.documentDirectory}receipts/`;
        
        // Ensure the receipts directory exists
        await FileSystem.makeDirectoryAsync(directory, { intermediates: true });
        
        // Copy the image to our app's permanent storage
        const newPath = directory + filename;
        await FileSystem.copyAsync({
          from: newUri,
          to: newPath
        });
        
        setReceiptUri(newPath);
      }
    } catch (error) {
      console.log('Error picking image:', error);
    }
  };

  const handleSubmit = () => {
    if (!amount || !month || !day || !year) {
      return;
    }

    const date = new Date(parseInt(year), parseInt(month) - 1, parseInt(day));

    addPayment(id, {
      amount: parseFloat(unformatNumber(amount)),
      date: date.toISOString(),
      note: note || undefined,
      receiptUrl: receiptUri || undefined,
    });

    router.back();
  };

  if (!loan) {
    return (
      <View style={styles.container}>
        <Text style={styles.emptyText}>Loan not found</Text>
      </View>
    );
  }

  return (
    <>
      <Stack.Screen options={{ title: "Add Payment" }} />
      
      <ScrollView style={styles.container}>
        <View style={styles.form}>
          <View style={styles.field}>
            <Text style={styles.label}>Payment Amount</Text>
            <TextInput
              style={styles.input}
              value={amount}
              onChangeText={handleAmountChange}
              placeholder="Enter amount"
              keyboardType="numeric"
              placeholderTextColor={colors.textSecondary}
            />
          </View>

          <View style={styles.field}>
            <Text style={styles.label}>Payment Date</Text>
            <View style={styles.dateInputs}>
              <TextInput
                style={styles.dateInput}
                value={month}
                onChangeText={(text) => {
                  const num = parseInt(text);
                  if (text === '' || (num >= 1 && num <= 12)) {
                    setMonth(text);
                  }
                }}
                placeholder="MM"
                keyboardType="numeric"
                maxLength={2}
                placeholderTextColor={colors.textSecondary}
              />
              <Text style={styles.dateSeparator}>/</Text>
              <TextInput
                style={styles.dateInput}
                value={day}
                onChangeText={(text) => {
                  const num = parseInt(text);
                  if (text === '' || (num >= 1 && num <= 31)) {
                    setDay(text);
                  }
                }}
                placeholder="DD"
                keyboardType="numeric"
                maxLength={2}
                placeholderTextColor={colors.textSecondary}
              />
              <Text style={styles.dateSeparator}>/</Text>
              <TextInput
                style={[styles.dateInput, styles.yearInput]}
                value={year}
                onChangeText={setYear}
                placeholder="YYYY"
                keyboardType="numeric"
                maxLength={4}
                placeholderTextColor={colors.textSecondary}
              />
            </View>
          </View>

          <View style={styles.field}>
            <Text style={styles.label}>Upload Receipt</Text>
            <Pressable style={styles.uploadButton} onPress={pickReceipt}>
              <Upload size={24} color={colors.text} />
              <Text style={styles.uploadText}>
                {receiptUri ? 'Change Receipt' : 'Select Receipt'}
              </Text>
            </Pressable>
            {receiptUri && (
              <Image 
                source={{ uri: receiptUri }} 
                style={styles.receiptPreview}
                resizeMode="cover"
              />
            )}
          </View>

          <View style={styles.field}>
            <Text style={styles.label}>Note (Optional)</Text>
            <TextInput
              style={[styles.input, styles.noteInput]}
              value={note}
              onChangeText={setNote}
              placeholder="Add a note"
              multiline
              placeholderTextColor={colors.textSecondary}
            />
          </View>

          <Pressable 
            style={styles.button} 
            onPress={handleSubmit}
          >
            <Text style={styles.buttonText}>Add Payment</Text>
          </Pressable>
        </View>
      </ScrollView>
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  form: {
    padding: 16,
    gap: 16,
  },
  field: {
    gap: 8,
  },
  label: {
    fontSize: 14,
    fontWeight: '500',
    color: colors.text,
  },
  input: {
    backgroundColor: colors.inputBackground,
    borderRadius: 8,
    padding: 12,
    color: colors.text,
    borderWidth: 1,
    borderColor: colors.border,
  },
  noteInput: {
    height: 100,
    textAlignVertical: 'top',
  },
  dateInputs: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  dateInput: {
    backgroundColor: colors.inputBackground,
    borderRadius: 8,
    padding: 12,
    color: colors.text,
    borderWidth: 1,
    borderColor: colors.border,
    width: 60,
    textAlign: 'center',
  },
  yearInput: {
    width: 80,
  },
  dateSeparator: {
    color: colors.text,
    fontSize: 18,
  },
  uploadButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    backgroundColor: colors.inputBackground,
    borderRadius: 8,
    padding: 12,
    borderWidth: 1,
    borderColor: colors.border,
  },
  uploadText: {
    color: colors.text,
    fontSize: 16,
  },
  receiptPreview: {
    width: '100%',
    height: 200,
    borderRadius: 8,
    marginTop: 8,
  },
  button: {
    backgroundColor: colors.primary,
    padding: 16,
    borderRadius: 8,
    alignItems: 'center',
    marginTop: 16,
  },
  buttonText: {
    color: colors.text,
    fontSize: 16,
    fontWeight: '600',
  },
  emptyText: {
    textAlign: 'center',
    color: colors.textSecondary,
    fontSize: 16,
    marginTop: 24,
  },
});