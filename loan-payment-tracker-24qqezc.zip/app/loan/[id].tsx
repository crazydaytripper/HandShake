import { View, Text, StyleSheet, ScrollView, Pressable, Image } from 'react-native';
import { Stack, useLocalSearchParams, router } from 'expo-router';
import { Trash2, FileText } from 'lucide-react-native';
import { useLoanStore } from '@/stores/loan-store';
import { colors } from '@/constants/colors';
import { calculateEstimatedPayoff } from '@/utils/loan-calculations';
import * as FileSystem from 'expo-file-system';
import * as Sharing from 'expo-sharing';

const formatNumber = (num: number | undefined | null): string => {
  if (num === undefined || num === null) return '0.00';
  return num.toLocaleString(undefined, {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });
};

const formatDate = (dateStr: string): string => {
  const date = new Date(dateStr);
  return date.toLocaleDateString('en-US', {
    month: 'numeric',
    day: 'numeric',
    year: 'numeric'
  });
};

const formatEstimatedDate = (date: Date): string => {
  return date.toLocaleDateString('en-US', {
    month: 'long',
    year: 'numeric'
  });
};

export default function LoanDetailsScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const { loans, deleteLoan } = useLoanStore();
  const loan = loans.find(l => l.id === id);

  const handleViewReceipt = async (receiptUrl: string) => {
    try {
      if (await Sharing.isAvailableAsync()) {
        await Sharing.shareAsync(receiptUrl);
      }
    } catch (error) {
      console.log('Error sharing receipt:', error);
    }
  };

  if (!loan) {
    return (
      <View style={styles.container}>
        <Text style={styles.emptyText}>Loan not found</Text>
      </View>
    );
  }

  const handleDelete = async () => {
    // Clean up receipt files before deleting loan
    for (const payment of loan.payments) {
      if (payment.receiptUrl) {
        try {
          await FileSystem.deleteAsync(payment.receiptUrl);
        } catch (error) {
          console.log('Error deleting receipt:', error);
        }
      }
    }
    deleteLoan(loan.id);
    router.back();
  };

  const totalPaid = loan.payments.reduce((sum, payment) => sum + payment.amount, 0);
  const progressPercentage = loan.amount > 0 
    ? ((loan.amount - loan.remainingAmount) / loan.amount) * 100
    : 0;

  const totalAdditionalPayments = loan.payments.reduce((sum, payment) => {
    return sum + Math.max(0, payment.amount - loan.monthlyPayment);
  }, 0);
  const monthsWithPayments = new Set(
    loan.payments.map(p => {
      const date = new Date(p.date);
      return `${date.getMonth()}-${date.getFullYear()}`;
    })
  ).size;
  const averageAdditionalMonthly = monthsWithPayments > 0 
    ? totalAdditionalPayments / monthsWithPayments 
    : 0;

  const payoffEstimate = calculateEstimatedPayoff(
    loan.remainingAmount,
    loan.monthlyPayment,
    loan.interestRate,
    averageAdditionalMonthly
  );

  const sortedPayments = [...loan.payments].sort((a, b) => 
    new Date(b.date).getTime() - new Date(a.date).getTime()
  );

  return (
    <View style={styles.container}>
      <Stack.Screen 
        options={{
          headerRight: () => (
            <Pressable 
              style={styles.headerButton} 
              onPress={handleDelete}
            >
              <Trash2 size={24} color={colors.error} />
            </Pressable>
          ),
        }} 
      />
      
      <ScrollView style={styles.scrollView}>
        <View style={styles.header}>
          <Text style={styles.title}>{loan.title}</Text>
          <Text style={styles.amount}>
            {loan.currency} {formatNumber(loan.remainingAmount)}
          </Text>
          <Text style={styles.subtitle}>remaining balance</Text>
        </View>

        <View style={styles.progressContainer}>
          <View style={styles.progressBar}>
            <View 
              style={[
                styles.progressFill,
                { width: `${progressPercentage}%` }
              ]} 
            />
          </View>
          <Text style={styles.progressText}>
            {progressPercentage.toFixed(1)}% paid off
          </Text>
        </View>

        <View style={styles.statsContainer}>
          <View style={styles.stat}>
            <Text style={styles.statLabel}>Original Amount</Text>
            <Text style={styles.statValue}>
              {loan.currency} {formatNumber(loan.amount)}
            </Text>
          </View>
          <View style={styles.stat}>
            <Text style={styles.statLabel}>Interest Rate</Text>
            <Text style={styles.statValue}>{loan.interestRate}%</Text>
          </View>
          <View style={styles.stat}>
            <Text style={styles.statLabel}>Monthly Payment</Text>
            <Text style={styles.statValue}>
              {loan.currency} {formatNumber(loan.monthlyPayment)}
            </Text>
          </View>
          <View style={styles.stat}>
            <Text style={styles.statLabel}>Total Interest Paid</Text>
            <Text style={styles.statValue}>
              {loan.currency} {formatNumber(loan.totalInterestPaid)}
            </Text>
          </View>
          <View style={styles.stat}>
            <Text style={styles.statLabel}>Total Principal Paid</Text>
            <Text style={styles.statValue}>
              {loan.currency} {formatNumber(loan.amount - loan.remainingAmount)}
            </Text>
          </View>
          <View style={[styles.stat, styles.totalPaidStat]}>
            <Text style={styles.statLabel}>Total Paid</Text>
            <Text style={styles.statValue}>
              {loan.currency} {formatNumber(totalPaid)}
            </Text>
          </View>
        </View>

        <View style={styles.payoffEstimate}>
          <Text style={styles.payoffTitle}>Estimated Payoff</Text>
          <Text style={styles.payoffDate}>
            {formatEstimatedDate(payoffEstimate.date)}
          </Text>
          <Text style={styles.payoffMonths}>
            {payoffEstimate.monthsLeft} months remaining
          </Text>
        </View>

        <View style={styles.paymentsContainer}>
          <View style={styles.paymentsHeader}>
            <Text style={styles.paymentsTitle}>Payment History</Text>
            <Pressable
              style={styles.addButton}
              onPress={() => router.push(`/loan/${id}/add-payment`)}
            >
              <Text style={styles.addButtonText}>Add Payment</Text>
            </Pressable>
          </View>

          {sortedPayments.map((payment, index) => (
            <View key={payment.id} style={styles.payment}>
              <View style={styles.paymentHeader}>
                <Text style={styles.paymentAmount}>
                  {loan.currency} {formatNumber(payment.amount)}
                </Text>
                <Text style={styles.paymentDate}>
                  {formatDate(payment.date)}
                </Text>
              </View>
              <View style={styles.paymentDetails}>
                <Text style={styles.paymentDetail}>
                  Principal: {loan.currency} {formatNumber(payment.principalPortion)}
                </Text>
                <Text style={styles.paymentDetail}>
                  Interest: {loan.currency} {formatNumber(payment.interestPortion)}
                </Text>
              </View>
              {payment.note && (
                <Text style={styles.paymentNote}>{payment.note}</Text>
              )}
              {payment.receiptUrl && (
                <Pressable
                  style={styles.receiptButton}
                  onPress={() => handleViewReceipt(payment.receiptUrl!)}
                >
                  <FileText size={20} color={colors.primary} />
                  <Text style={styles.receiptButtonText}>View Receipt</Text>
                </Pressable>
              )}
            </View>
          ))}
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  headerButton: {
    marginRight: 16,
    padding: 8,
  },
  scrollView: {
    flex: 1,
  },
  header: {
    padding: 16,
    alignItems: 'center',
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  title: {
    fontSize: 24,
    fontWeight: '700',
    color: colors.text,
    marginBottom: 8,
  },
  amount: {
    fontSize: 36,
    fontWeight: '700',
    color: colors.text,
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 16,
    color: colors.textSecondary,
  },
  progressContainer: {
    padding: 16,
    gap: 8,
  },
  progressBar: {
    height: 8,
    backgroundColor: colors.border,
    borderRadius: 4,
    overflow: 'hidden',
  },
  progressFill: {
    height: '100%',
    backgroundColor: colors.primary,
  },
  progressText: {
    fontSize: 14,
    color: colors.textSecondary,
    textAlign: 'center',
  },
  statsContainer: {
    padding: 16,
    gap: 16,
  },
  stat: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  totalPaidStat: {
    marginTop: 8,
    paddingTop: 16,
    borderTopWidth: 1,
    borderTopColor: colors.border,
  },
  statLabel: {
    fontSize: 14,
    color: colors.textSecondary,
  },
  statValue: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.text,
  },
  payoffEstimate: {
    padding: 16,
    backgroundColor: colors.card,
    marginHorizontal: 16,
    borderRadius: 12,
    alignItems: 'center',
    gap: 4,
    marginBottom: 16,
  },
  payoffTitle: {
    fontSize: 16,
    color: colors.textSecondary,
    marginBottom: 4,
  },
  payoffDate: {
    fontSize: 24,
    fontWeight: '600',
    color: colors.text,
  },
  payoffMonths: {
    fontSize: 14,
    color: colors.textSecondary,
  },
  paymentsContainer: {
    padding: 16,
    gap: 16,
  },
  paymentsHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  paymentsTitle: {
    fontSize: 20,
    fontWeight: '600',
    color: colors.text,
  },
  addButton: {
    backgroundColor: colors.primary,
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 8,
  },
  addButtonText: {
    color: colors.text,
    fontSize: 14,
    fontWeight: '500',
  },
  payment: {
    backgroundColor: colors.card,
    padding: 16,
    borderRadius: 12,
    gap: 8,
  },
  paymentHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  paymentAmount: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.text,
  },
  paymentDate: {
    fontSize: 14,
    color: colors.textSecondary,
  },
  paymentDetails: {
    gap: 4,
  },
  paymentDetail: {
    fontSize: 14,
    color: colors.textSecondary,
  },
  paymentNote: {
    fontSize: 14,
    color: colors.textSecondary,
    fontStyle: 'italic',
  },
  receiptButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingVertical: 8,
  },
  receiptButtonText: {
    color: colors.primary,
    fontSize: 14,
    fontWeight: '500',
  },
  emptyText: {
    fontSize: 16,
    color: colors.textSecondary,
    textAlign: 'center',
    marginTop: 24,
  },
});