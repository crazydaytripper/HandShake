export const calculateMonthlyInterest = (principal: number, annualRate: number): number => {
  // Convert annual rate to monthly (12% annual = 1% monthly)
  const monthlyRate = annualRate / 100 / 12;
  return principal * monthlyRate;
};

export const calculatePaymentBreakdown = (
  remainingBalance: number,
  paymentAmount: number,
  annualInterestRate: number
) => {
  // Calculate standard monthly interest
  const standardMonthlyInterest = calculateMonthlyInterest(remainingBalance, annualInterestRate);
  
  // Payment tiers and calculations
  if (paymentAmount <= 20000) {
    // For payments up to 20k, use percentage of payment as interest
    const interestPortion = paymentAmount * (annualInterestRate / 100);
    return {
      interestPortion,
      principalPortion: paymentAmount - interestPortion
    };
  } 
  else if (paymentAmount <= 30000) {
    // For payments between 20k-30k, use weighted calculation
    // As payment increases from 20k to 30k, gradually shift from payment-based to standard interest
    const weight = (paymentAmount - 20000) / 10000; // 0 at 20k, 1 at 30k
    
    // Calculate both methods
    const paymentBasedInterest = paymentAmount * (annualInterestRate / 100);
    
    // Weighted average between the two methods
    const interestPortion = (paymentBasedInterest * (1 - weight)) + (standardMonthlyInterest * weight);
    
    return {
      interestPortion,
      principalPortion: paymentAmount - interestPortion
    };
  } 
  else {
    // For payments over 30k, use standard interest calculation
    return {
      interestPortion: standardMonthlyInterest,
      principalPortion: paymentAmount - standardMonthlyInterest
    };
  }
};

export const calculateEstimatedPayoff = (
  remainingBalance: number,
  monthlyPayment: number,
  annualInterestRate: number,
  additionalPayments: number = 0 // Average of additional payments per month
): { date: Date; monthsLeft: number } => {
  if (remainingBalance <= 0 || monthlyPayment <= 0) {
    return { date: new Date(), monthsLeft: 0 };
  }

  const monthlyRate = annualInterestRate / 100 / 12;
  const effectiveMonthlyPayment = monthlyPayment + additionalPayments;
  
  // Using the loan amortization formula to calculate months
  // P = L[c(1 + c)^n]/[(1 + c)^n - 1]
  // where:
  // P = Payment
  // L = Loan amount (remaining balance)
  // c = monthly interest rate
  // n = number of months
  // Solving for n:
  // n = ln(P/(P-Lc))/ln(1+c)
  
  const monthsLeft = Math.ceil(
    Math.log(effectiveMonthlyPayment / (effectiveMonthlyPayment - (remainingBalance * monthlyRate))) /
    Math.log(1 + monthlyRate)
  );
  
  const estimatedDate = new Date();
  estimatedDate.setMonth(estimatedDate.getMonth() + monthsLeft);

  return {
    date: estimatedDate,
    monthsLeft
  };
};