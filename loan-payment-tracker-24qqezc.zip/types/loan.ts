export type Currency = 'THB' | 'USD' | 'EUR';

export interface Payment {
  id: string;
  amount: number;
  date: string;
  interestPortion: number;
  principalPortion: number;
  receiptUrl?: string;
  note?: string;
}

export interface Loan {
  id: string;
  title: string;
  amount: number;
  currency: Currency;
  interestRate: number;
  startDate: string;
  monthlyPayment: number;
  remainingAmount: number;
  totalInterestPaid: number;
  payments: Payment[];
  nextPaymentDue: string;
  receiptUrl?: string;
}

export interface User {
  id: string;
  email: string;
  name: string;
}