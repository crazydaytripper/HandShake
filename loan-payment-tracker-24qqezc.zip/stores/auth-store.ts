import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { User } from '@/types/loan';

interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  login: (email: string, password: string) => Promise<void>;
  logout: () => void;
  signup: (email: string, password: string, name: string) => Promise<void>;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      user: null,
      isAuthenticated: false,
      login: async (email, password) => {
        // Mock login
        set({
          user: { id: '1', email, name: 'John Doe' },
          isAuthenticated: true
        });
      },
      logout: () => {
        set({ user: null, isAuthenticated: false });
      },
      signup: async (email, password, name) => {
        // Mock signup
        set({
          user: { id: '1', email, name },
          isAuthenticated: true
        });
      }
    }),
    {
      name: 'auth-storage',
      storage: createJSONStorage(() => AsyncStorage)
    }
  )
);