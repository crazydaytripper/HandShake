import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Loan, Payment } from '@/types/loan';
import { calculatePaymentBreakdown } from '@/utils/loan-calculations';

interface LoanState {
  loans: Loan[];
  addLoan: (loan: Omit<Loan, 'id' | 'payments' | 'remainingAmount' | 'totalInterestPaid'>) => void;
  addPayment: (loanId: string, payment: Omit<Payment, 'id' | 'interestPortion' | 'principalPortion'>) => void;
  deleteLoan: (id: string) => void;
  updateLoan: (id: string, loan: Partial<Loan>) => void;
}

export const useLoanStore = create<LoanState>()(
  persist(
    (set, get) => ({
      loans: [],
      addLoan: (loan) => {
        set((state) => ({
          loans: [...state.loans, {
            ...loan,
            id: Date.now().toString(),
            payments: [],
            remainingAmount: loan.amount,
            totalInterestPaid: 0,
            nextPaymentDue: new Date().toISOString() // Initialize with current date
          }]
        }));
      },
      addPayment: (loanId, payment) => {
        const loan = get().loans.find(l => l.id === loanId);
        if (!loan) return;

        const { interestPortion, principalPortion } = calculatePaymentBreakdown(
          loan.remainingAmount,
          payment.amount,
          loan.interestRate
        );

        const newPayment = {
          ...payment,
          id: Date.now().toString(),
          interestPortion,
          principalPortion
        };

        set((state) => ({
          loans: state.loans.map(loan => {
            if (loan.id === loanId) {
              // Calculate new remaining amount
              const newRemainingAmount = Math.max(0, loan.remainingAmount - principalPortion);
              
              // Calculate next payment due date (1 month from last payment or current date)
              const nextPaymentDate = new Date(payment.date);
              nextPaymentDate.setMonth(nextPaymentDate.getMonth() + 1);

              return {
                ...loan,
                payments: [...loan.payments, newPayment],
                remainingAmount: newRemainingAmount,
                totalInterestPaid: loan.totalInterestPaid + interestPortion,
                nextPaymentDue: nextPaymentDate.toISOString()
              };
            }
            return loan;
          })
        }));
      },
      deleteLoan: (id) => {
        set((state) => ({
          loans: state.loans.filter(loan => loan.id !== id)
        }));
      },
      updateLoan: (id, updatedLoan) => {
        set((state) => ({
          loans: state.loans.map(loan => 
            loan.id === id ? { ...loan, ...updatedLoan } : loan
          )
        }));
      }
    }),
    {
      name: 'loan-storage',
      storage: createJSONStorage(() => AsyncStorage),
      version: 1,
    }
  )
);